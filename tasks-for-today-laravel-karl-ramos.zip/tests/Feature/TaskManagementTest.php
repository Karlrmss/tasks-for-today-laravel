<?php

namespace Tests\Feature;

use App\Mail\TaskCompleted;
use App\Models\Task;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class TaskManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_pages_and_active_tasks_are_visible_to_guests(): void
    {
        $active = Task::factory()->create(['title' => 'Visible task']);
        Task::factory()->create(['title' => 'Archived task', 'is_archived' => true]);

        $this->get('/')->assertOk()->assertSee('Your day, clearly organized.');
        $this->get('/about')->assertOk()->assertSee('Completion notifications');
        $this->get('/profile')->assertOk()->assertSee('Karl Ramos');
        $this->get('/tasks')->assertOk()->assertSee($active->title)->assertDontSee('Archived task');
        $this->get(route('tasks.show', $active))->assertOk()->assertSee($active->description);
    }

    public function test_management_routes_require_authentication(): void
    {
        $task = Task::factory()->create();

        $this->get(route('tasks.create'))->assertRedirect(route('login'));
        $this->post(route('tasks.store'), [])->assertRedirect(route('login'));
        $this->get(route('tasks.edit', $task))->assertRedirect(route('login'));
        $this->put(route('tasks.update', $task), [])->assertRedirect(route('login'));
        $this->delete(route('tasks.destroy', $task))->assertRedirect(route('login'));
        $this->get(route('tasks.archived'))->assertRedirect(route('login'));
    }

    public function test_authenticated_user_can_create_update_archive_and_restore_a_task(): void
    {
        $this->actingAs(User::factory()->create());

        $data = [
            'title' => 'Write assessment report',
            'description' => 'Document the complete implementation and test results.',
            'due_date' => '2026-12-01',
            'priority' => 'high',
            'status' => 'pending',
        ];

        $this->post(route('tasks.store'), $data)->assertRedirect(route('tasks.index'));
        $task = Task::where('title', $data['title'])->firstOrFail();

        $this->put(route('tasks.update', $task), array_merge($data, [
            'title' => 'Write final assessment report',
            'status' => 'in_progress',
        ]))->assertRedirect(route('tasks.show', $task));

        $this->assertDatabaseHas('tasks', ['id' => $task->id, 'title' => 'Write final assessment report']);
        $this->delete(route('tasks.destroy', $task))->assertRedirect(route('tasks.index'));
        $this->assertDatabaseHas('tasks', ['id' => $task->id, 'is_archived' => true]);

        $this->patch(route('tasks.restore', $task))->assertRedirect(route('tasks.archived'));
        $this->assertDatabaseHas('tasks', ['id' => $task->id, 'is_archived' => false]);
    }

    public function test_task_input_is_validated(): void
    {
        $this->actingAs(User::factory()->create());

        $this->post(route('tasks.store'), [
            'title' => '',
            'description' => '',
            'due_date' => 'not-a-date',
            'priority' => 'urgent',
            'status' => 'unknown',
        ])->assertSessionHasErrors(['title', 'description', 'due_date', 'priority', 'status']);

        $this->assertDatabaseCount('tasks', 0);
    }

    public function test_email_is_sent_once_when_status_changes_to_done(): void
    {
        Mail::fake();
        config(['tasks.completion_recipient' => 'manager@example.com']);
        $this->actingAs(User::factory()->create());
        $task = Task::factory()->create(['status' => 'pending']);
        $data = [
            'title' => $task->title,
            'description' => $task->description,
            'due_date' => $task->due_date->format('Y-m-d'),
            'priority' => $task->priority,
            'status' => 'done',
        ];

        $this->put(route('tasks.update', $task), $data)->assertRedirect(route('tasks.show', $task));

        Mail::assertSent(
            TaskCompleted::class,
            fn (TaskCompleted $mail) => $mail->hasTo('manager@example.com') && $mail->task->is($task)
        );

        $this->put(route('tasks.update', $task), $data);
        Mail::assertSentCount(1);
    }

    public function test_changing_to_a_non_done_status_does_not_send_email(): void
    {
        Mail::fake();
        $this->actingAs(User::factory()->create());
        $task = Task::factory()->create(['status' => 'pending']);

        $this->put(route('tasks.update', $task), [
            'title' => $task->title,
            'description' => $task->description,
            'due_date' => $task->due_date->format('Y-m-d'),
            'priority' => $task->priority,
            'status' => 'in_progress',
        ]);

        Mail::assertNothingSent();
    }
}

<!DOCTYPE html>
<html lang="en"><body style="margin:0;padding:32px;background:#f5f3eb;color:#18201c;font-family:Arial,sans-serif;line-height:1.6">
<div style="max-width:620px;margin:auto;background:#fffef9;border:1px solid #dddcd2;border-radius:16px;overflow:hidden">
    <div style="padding:24px 30px;background:#1f6f54;color:white"><strong style="font-size:20px">✓ Tasks for Today</strong></div>
    <div style="padding:30px">
        <p style="margin-top:0;color:#1f6f54;font-weight:bold;text-transform:uppercase;letter-spacing:1px;font-size:12px">Task completed</p>
        <h1 style="margin:0 0 16px;font-size:30px;line-height:1.2">{{ $task->title }}</h1>
        <p>{{ $task->description }}</p>
        <p><strong>Due date:</strong> {{ $task->due_date->format('F j, Y') }}<br><strong>Priority:</strong> {{ ucfirst($task->priority) }}</p>
        <p style="margin-bottom:0;color:#66736d">This automatic notification was sent because the task’s status changed to done.</p>
    </div>
</div>
</body></html>

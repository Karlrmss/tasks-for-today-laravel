@extends('layouts.app')

@section('title', $task->title)

@section('content')
<header class="page-header"><div class="container"><p class="eyebrow">Task details</p><h1 class="detail-title">{{ $task->title }}</h1><div class="page-actions"><span class="badge {{ $task->status }}">{{ $task->status_label }}</span><span class="badge {{ $task->priority }}">{{ ucfirst($task->priority) }} priority</span></div></div></header>
<div class="container detail-shell">
    <div class="panel">
        <div class="detail-description">{{ $task->description }}</div>
        <div class="detail-meta">
            <div class="meta-box"><span>Due date</span><strong>{{ $task->due_date->format('F j, Y') }}</strong></div>
            <div class="meta-box"><span>Created</span><strong>{{ $task->created_at->format('M j, Y') }}</strong></div>
            <div class="meta-box"><span>Last updated</span><strong>{{ $task->updated_at->diffForHumans() }}</strong></div>
        </div>
        <div class="page-actions">
            <a class="button secondary" href="{{ route('tasks.index') }}">← Back to tasks</a>
            @auth
                @unless ($task->is_archived)
                    <a class="button" href="{{ route('tasks.edit', $task) }}">Edit task</a>
                    <form class="inline" action="{{ route('tasks.destroy', $task) }}" method="POST" onsubmit="return confirm('Archive this task?')">@csrf @method('DELETE')<button class="button danger" type="submit">Archive</button></form>
                @endunless
            @endauth
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')

@section('title', 'Edit task')

@section('content')
<header class="page-header"><div class="container"><p class="eyebrow">Refine the plan</p><h1>Edit task</h1><p>Update details or mark the work as complete.</p></div></header>
<div class="container form-shell"><form class="panel" action="{{ route('tasks.update', $task) }}" method="POST">@csrf @method('PUT') @include('tasks._form', ['submitLabel' => 'Save changes'])</form></div>
@endsection

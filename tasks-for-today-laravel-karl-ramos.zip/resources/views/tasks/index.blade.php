@extends('layouts.app')

@section('title', 'Task list')

@section('content')
<header class="page-header">
    <div class="container row">
        <div><p class="eyebrow">Keep the momentum</p><h1>Task list</h1><p>Browse current work and see what needs attention.</p></div>
        @auth <a class="button" href="{{ route('tasks.create') }}">+ Create task</a> @endauth
    </div>
</header>

<section class="container">
    <form class="filters" action="{{ route('tasks.index') }}" method="GET">
        <input name="search" value="{{ request('search') }}" placeholder="Search title or description…" aria-label="Search tasks">
        <select name="status" aria-label="Filter by status">
            <option value="">All statuses</option>
            <option value="pending" @selected(request('status') === 'pending')>Pending</option>
            <option value="in_progress" @selected(request('status') === 'in_progress')>In progress</option>
            <option value="done" @selected(request('status') === 'done')>Done</option>
        </select>
        <button class="button" type="submit">Filter tasks</button>
    </form>

    <div class="task-grid">
        @forelse ($tasks as $task)
            <article class="task-card">
                <div class="task-card-top"><span class="badge {{ $task->status }}">{{ $task->status_label }}</span><span class="badge {{ $task->priority }}">{{ ucfirst($task->priority) }}</span></div>
                <h3><a href="{{ route('tasks.show', $task) }}">{{ $task->title }}</a></h3>
                <p>{{ $task->description }}</p>
                <div class="task-meta"><span>Due {{ $task->due_date->format('M j, Y') }}</span><a href="{{ route('tasks.show', $task) }}">View details →</a></div>
            </article>
        @empty
            <div class="empty"><h3>No tasks found</h3><p>Try a different filter{{ auth()->check() ? ' or create the first task.' : '.' }}</p></div>
        @endforelse
    </div>

    @if ($tasks->hasPages())
        <nav class="pagination" aria-label="Task pages">
            @if ($tasks->onFirstPage()) <span>‹</span> @else <a href="{{ $tasks->previousPageUrl() }}">‹</a> @endif
            <span class="active">{{ $tasks->currentPage() }}</span><span>of {{ $tasks->lastPage() }}</span>
            @if ($tasks->hasMorePages()) <a href="{{ $tasks->nextPageUrl() }}">›</a> @else <span>›</span> @endif
        </nav>
    @endif
</section>
@endsection

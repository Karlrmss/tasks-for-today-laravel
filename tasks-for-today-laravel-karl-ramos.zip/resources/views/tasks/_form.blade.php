@if ($errors->any())
    <div class="alert error-alert" role="alert">Please correct the highlighted fields and try again.</div>
@endif

<div class="field">
    <label for="title">Task title</label>
    <input id="title" name="title" value="{{ old('title', $task->title ?? '') }}" maxlength="120" required autofocus>
    @error('title') <span class="error">{{ $message }}</span> @enderror
</div>

<div class="field">
    <label for="description">Description</label>
    <textarea id="description" name="description" maxlength="2000" required>{{ old('description', $task->description ?? '') }}</textarea>
    @error('description') <span class="error">{{ $message }}</span> @enderror
</div>

<div class="field-row">
    <div class="field">
        <label for="due_date">Due date</label>
        <input id="due_date" name="due_date" type="date" value="{{ old('due_date', isset($task) ? $task->due_date->format('Y-m-d') : now()->format('Y-m-d')) }}" required>
        @error('due_date') <span class="error">{{ $message }}</span> @enderror
    </div>
    <div class="field">
        <label for="priority">Priority</label>
        <select id="priority" name="priority" required>
            @foreach (['low' => 'Low', 'medium' => 'Medium', 'high' => 'High'] as $value => $label)
                <option value="{{ $value }}" @selected(old('priority', $task->priority ?? 'medium') === $value)>{{ $label }}</option>
            @endforeach
        </select>
        @error('priority') <span class="error">{{ $message }}</span> @enderror
    </div>
    <div class="field">
        <label for="status">Status</label>
        <select id="status" name="status" required>
            @foreach (['pending' => 'Pending', 'in_progress' => 'In progress', 'done' => 'Done'] as $value => $label)
                <option value="{{ $value }}" @selected(old('status', $task->status ?? 'pending') === $value)>{{ $label }}</option>
            @endforeach
        </select>
        @error('status') <span class="error">{{ $message }}</span> @enderror
    </div>
</div>

<div class="page-actions">
    <button class="button" type="submit">{{ $submitLabel }}</button>
    <a class="button secondary" href="{{ isset($task) ? route('tasks.show', $task) : route('tasks.index') }}">Cancel</a>
</div>

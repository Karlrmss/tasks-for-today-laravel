@extends('layouts.app')

@section('title', 'Task archive')

@section('content')
<header class="page-header"><div class="container"><p class="eyebrow">Out of sight, not erased</p><h1>Task archive</h1><p>Restore previously archived records whenever they are needed.</p></div></header>
<div class="container archive-list">
    @forelse ($tasks as $task)
        <article class="archive-item"><div><h3>{{ $task->title }}</h3><p>Archived {{ $task->updated_at->diffForHumans() }} · {{ $task->status_label }}</p></div><form action="{{ route('tasks.restore', $task) }}" method="POST">@csrf @method('PATCH')<button class="button secondary small" type="submit">Restore</button></form></article>
    @empty
        <div class="empty"><h3>The archive is empty</h3><p>Archived tasks will appear here.</p></div>
    @endforelse
</div>
@endsection

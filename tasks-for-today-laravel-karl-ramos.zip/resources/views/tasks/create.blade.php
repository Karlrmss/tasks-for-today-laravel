@extends('layouts.app')

@section('title', 'Create task')

@section('content')
<header class="page-header"><div class="container"><p class="eyebrow">Add to the plan</p><h1>Create a task</h1><p>Give the work a clear name, deadline, and priority.</p></div></header>
<div class="container form-shell"><form class="panel" action="{{ route('tasks.store') }}" method="POST">@csrf @include('tasks._form', ['submitLabel' => 'Create task'])</form></div>
@endsection

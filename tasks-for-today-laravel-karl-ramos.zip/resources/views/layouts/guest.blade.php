@extends('layouts.app')

@section('content')
    <div class="container auth-wrap">
        <div class="auth-card">{{ $slot }}</div>
    </div>
@endsection

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="Tasks for Today — a simple Laravel task management system by Karl Ramos.">
    <title>@yield('title', 'Tasks for Today') · Karl Ramos</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <header class="site-header">
        <nav class="container nav" aria-label="Main navigation">
            <a class="brand" href="{{ route('welcome') }}">
                <span class="brand-mark">✓</span>
                <span>Tasks for Today</span>
            </a>
            <div class="nav-links">
                <a class="{{ request()->routeIs('welcome') ? 'active' : '' }}" href="{{ route('welcome') }}">Home</a>
                <a class="{{ request()->routeIs('tasks.*') && ! request()->routeIs('tasks.archived') ? 'active' : '' }}" href="{{ route('tasks.index') }}">Tasks</a>
                <a class="{{ request()->routeIs('profile.public') ? 'active' : '' }}" href="{{ route('profile.public') }}">Profile</a>
                <a class="{{ request()->routeIs('about') ? 'active' : '' }}" href="{{ route('about') }}">About</a>
                @auth
                    <a class="{{ request()->routeIs('tasks.archived') ? 'active' : '' }}" href="{{ route('tasks.archived') }}">Archive</a>
                    <a class="{{ request()->routeIs('profile.edit') ? 'active' : '' }}" href="{{ route('profile.edit') }}">Account</a>
                @endauth
            </div>
            <div class="nav-actions">
                @auth
                    <a class="button small" href="{{ route('tasks.create') }}">+ New task</a>
                    <form class="inline" action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="logout-button" type="submit">Log out</button>
                    </form>
                @else
                    <a class="button secondary small" href="{{ route('login') }}">Log in</a>
                    <a class="button small" href="{{ route('register') }}">Register</a>
                @endauth
            </div>
        </nav>
        <nav class="mobile-nav" aria-label="Mobile navigation">
            <a href="{{ route('welcome') }}">Home</a><a href="{{ route('tasks.index') }}">Tasks</a><a href="{{ route('profile.public') }}">Profile</a><a href="{{ route('about') }}">About</a>
            @auth <a href="{{ route('tasks.archived') }}">Archive</a><a href="{{ route('profile.edit') }}">Account</a> @endauth
        </nav>
    </header>

    @if (session('success'))
        <div class="container alert" role="status">{{ session('success') }}</div>
    @endif

    <main>@yield('content')</main>

    <footer>
        <div class="container footer-inner">
            <span>Tasks for Today Management System</span>
            <span>Built with Laravel by Karl Ramos · {{ date('Y') }}</span>
        </div>
    </footer>
</body>
</html>

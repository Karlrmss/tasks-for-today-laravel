@extends('layouts.app')

@section('title', 'Plan the day')

@section('content')
<section class="hero">
    <div class="container hero-grid">
        <div>
            <p class="eyebrow">A calmer way to get things done</p>
            <h1>Your day, clearly organized.</h1>
            <p class="lead">Capture what matters, choose what comes next, and finish the day with fewer loose ends. Tasks for Today keeps your work visible without getting in the way.</p>
            <div class="hero-actions">
                <a class="button" href="{{ route('tasks.index') }}">View today’s tasks →</a>
                @guest <a class="button secondary" href="{{ route('register') }}">Create an account</a> @endguest
            </div>
        </div>
        <div class="hero-card" aria-label="Task list preview">
            <p class="eyebrow">Today · {{ now()->format('M j') }}</p>
            <div class="mini-task">
                <span class="check done">✓</span><div><strong>Plan the day</strong><span>Completed at 8:30 AM</span></div><span class="badge done">Done</span>
            </div>
            <div class="mini-task">
                <span class="check"></span><div><strong>Review Laravel project</strong><span>High priority</span></div><span class="badge high">High</span>
            </div>
            <div class="mini-task">
                <span class="check"></span><div><strong>Prepare documentation</strong><span>Due this week</span></div><span class="badge medium">Medium</span>
            </div>
        </div>
    </div>
</section>

<section class="section tint">
    <div class="container">
        <div class="section-heading">
            <p class="eyebrow">Everything in its place</p>
            <h2>Simple tools for focused work.</h2>
        </div>
        <div class="feature-grid">
            <article class="feature-card"><div class="feature-icon">01</div><h3>Prioritize clearly</h3><p>Use low, medium, and high priorities to make the next action obvious.</p></article>
            <article class="feature-card"><div class="feature-icon">02</div><h3>Track progress</h3><p>Move tasks from pending to in progress and done without losing context.</p></article>
            <article class="feature-card"><div class="feature-icon">03</div><h3>Stay informed</h3><p>A completion email is generated exactly once when work changes to done.</p></article>
        </div>
    </div>
</section>
@endsection

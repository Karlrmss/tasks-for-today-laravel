@extends('layouts.app')
@section('title', 'Confirm password')
@section('content')
<div class="container auth-wrap"><form class="auth-card" method="POST" action="{{ route('password.confirm') }}">
    @csrf
    <p class="eyebrow">Secure area</p><h1>Confirm password</h1><p>Please confirm your password before continuing.</p>
    <div class="field"><label for="password">Password</label><input id="password" type="password" name="password" required autocomplete="current-password" autofocus>@error('password') <span class="error">{{ $message }}</span> @enderror</div>
    <button class="button" type="submit">Confirm</button>
</form></div>
@endsection

@extends('layouts.app')
@section('title', 'Verify email')
@section('content')
<div class="container auth-wrap"><div class="auth-card">
    <p class="eyebrow">One last step</p><h1>Verify your email</h1><p>Check your inbox and follow the verification link. If it did not arrive, request another.</p>
    @if (session('status') === 'verification-link-sent') <div class="alert">A new verification link has been sent.</div> @endif
    <div class="page-actions"><form action="{{ route('verification.send') }}" method="POST">@csrf <button class="button" type="submit">Resend email</button></form><form action="{{ route('logout') }}" method="POST">@csrf <button class="button secondary" type="submit">Log out</button></form></div>
</div></div>
@endsection

@extends('layouts.app')
@section('title', 'Register')
@section('content')
<div class="container auth-wrap"><form class="auth-card" method="POST" action="{{ route('register') }}">
    @csrf
    <p class="eyebrow">Get organized</p><h1>Create account</h1><p>Register to create and manage tasks.</p>
    <div class="field"><label for="name">Name</label><input id="name" name="name" value="{{ old('name') }}" required autofocus autocomplete="name">@error('name') <span class="error">{{ $message }}</span> @enderror</div>
    <div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" value="{{ old('email') }}" required autocomplete="username">@error('email') <span class="error">{{ $message }}</span> @enderror</div>
    <div class="field"><label for="password">Password</label><input id="password" type="password" name="password" required autocomplete="new-password">@error('password') <span class="error">{{ $message }}</span> @enderror</div>
    <div class="field"><label for="password_confirmation">Confirm password</label><input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password"></div>
    <button class="button" type="submit">Create account</button>
    <p class="auth-footer">Already registered? <a href="{{ route('login') }}">Log in</a>.</p>
</form></div>
@endsection

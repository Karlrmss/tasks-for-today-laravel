@extends('layouts.app')
@section('title', 'Log in')
@section('content')
<div class="container auth-wrap"><form class="auth-card" method="POST" action="{{ route('login') }}">
    @csrf
    <p class="eyebrow">Welcome back</p><h1>Log in</h1><p>Continue managing today’s work.</p>
    @if (session('status')) <div class="alert">{{ session('status') }}</div> @endif
    <div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus autocomplete="username">@error('email') <span class="error">{{ $message }}</span> @enderror</div>
    <div class="field"><label for="password">Password</label><input id="password" type="password" name="password" required autocomplete="current-password">@error('password') <span class="error">{{ $message }}</span> @enderror</div>
    <div class="field remember"><input id="remember_me" type="checkbox" name="remember"><label for="remember_me">Remember me</label></div>
    <button class="button" type="submit">Log in</button>
    <p class="auth-footer"><a href="{{ route('password.request') }}">Forgot your password?</a><br>New here? <a href="{{ route('register') }}">Create an account</a>.</p>
</form></div>
@endsection

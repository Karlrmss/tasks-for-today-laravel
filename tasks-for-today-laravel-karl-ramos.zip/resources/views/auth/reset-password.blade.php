@extends('layouts.app')
@section('title', 'Choose a new password')
@section('content')
<div class="container auth-wrap"><form class="auth-card" method="POST" action="{{ route('password.store') }}">
    @csrf <input type="hidden" name="token" value="{{ $request->route('token') }}">
    <p class="eyebrow">Account recovery</p><h1>New password</h1><p>Choose a strong password for your account.</p>
    <div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" value="{{ old('email', $request->email) }}" required autofocus>@error('email') <span class="error">{{ $message }}</span> @enderror</div>
    <div class="field"><label for="password">Password</label><input id="password" type="password" name="password" required autocomplete="new-password">@error('password') <span class="error">{{ $message }}</span> @enderror</div>
    <div class="field"><label for="password_confirmation">Confirm password</label><input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password"></div>
    <button class="button" type="submit">Reset password</button>
</form></div>
@endsection

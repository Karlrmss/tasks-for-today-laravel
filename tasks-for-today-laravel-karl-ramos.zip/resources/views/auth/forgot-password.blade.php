@extends('layouts.app')
@section('title', 'Forgot password')
@section('content')
<div class="container auth-wrap"><form class="auth-card" method="POST" action="{{ route('password.email') }}">
    @csrf
    <p class="eyebrow">Account recovery</p><h1>Reset password</h1><p>Enter your email and we’ll send a secure password reset link.</p>
    @if (session('status')) <div class="alert">{{ session('status') }}</div> @endif
    <div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" value="{{ old('email') }}" required autofocus>@error('email') <span class="error">{{ $message }}</span> @enderror</div>
    <button class="button" type="submit">Email reset link</button>
    <p class="auth-footer"><a href="{{ route('login') }}">← Return to login</a></p>
</form></div>
@endsection

@extends('layouts.app')
@section('title', 'Account settings')
@section('content')
<header class="page-header"><div class="container"><p class="eyebrow">Private account</p><h1>Account settings</h1><p>Update your personal details, password, or account.</p></div></header>
<div class="container account-grid">
    @include('profile.partials.update-profile-information-form')
    @include('profile.partials.update-password-form')
    @include('profile.partials.delete-user-form')
</div>
@endsection

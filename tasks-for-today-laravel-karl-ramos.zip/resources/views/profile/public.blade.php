@extends('layouts.app')

@section('title', 'Karl Ramos')

@section('content')
<header class="page-header"><div class="container"><p class="eyebrow">Developer profile</p><h1>Karl Ramos</h1><p>Student developer · Laravel enthusiast · Practical problem solver</p></div></header>
<section class="section">
    <div class="container profile-grid">
        <div class="portrait" aria-label="Karl Ramos initials">KR</div>
        <div class="stack">
            <article class="panel prose"><h2>Hello, I’m Karl.</h2><p>I built Tasks for Today to explore how a Laravel application can respond to its own data changes while staying straightforward for its users. The project brings together secure authentication, clean MVC organization, validation, database migrations, and transactional email.</p><p>I care about software that feels calm, understandable, and dependable—the kind of tool people can use without needing a manual.</p></article>
            <div class="feature-grid">
                <article class="feature-card"><h3>Laravel</h3><p>MVC structure, Eloquent, Blade, Mail, and testing.</p></article>
                <article class="feature-card"><h3>UI design</h3><p>Responsive, accessible interfaces with a clear visual hierarchy.</p></article>
                <article class="feature-card"><h3>Quality</h3><p>Validation, authorization, automated tests, and documentation.</p></article>
            </div>
        </div>
    </div>
</section>
@endsection

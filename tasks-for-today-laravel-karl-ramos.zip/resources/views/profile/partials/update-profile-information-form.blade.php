<section class="panel">
    <h2>Profile information</h2><p class="lead">Change the name and email address used for this account.</p>
    @if (session('status') === 'profile-updated') <div class="alert">Profile saved successfully.</div> @endif
    <form method="POST" action="{{ route('profile.update') }}">@csrf @method('PATCH')
        <div class="field"><label for="name">Name</label><input id="name" name="name" value="{{ old('name', $user->name) }}" required autocomplete="name">@error('name') <span class="error">{{ $message }}</span> @enderror</div>
        <div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" value="{{ old('email', $user->email) }}" required autocomplete="username">@error('email') <span class="error">{{ $message }}</span> @enderror</div>
        <button class="button" type="submit">Save profile</button>
    </form>
</section>

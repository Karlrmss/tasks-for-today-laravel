<section class="panel">
    <h2>Delete account</h2><p class="lead">This permanently removes your user account. Task records remain available to other registered managers.</p>
    <form method="POST" action="{{ route('profile.destroy') }}" onsubmit="return confirm('Permanently delete your account?')">@csrf @method('DELETE')
        <div class="field"><label for="delete_password">Confirm with your password</label><input id="delete_password" type="password" name="password" autocomplete="current-password">@error('password', 'userDeletion') <span class="error">{{ $message }}</span> @enderror</div>
        <button class="button danger" type="submit">Delete account</button>
    </form>
</section>

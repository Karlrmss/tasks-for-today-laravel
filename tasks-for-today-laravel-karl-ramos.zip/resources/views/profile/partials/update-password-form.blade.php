<section class="panel">
    <h2>Update password</h2><p class="lead">Use a long, unique password to keep your account secure.</p>
    @if (session('status') === 'password-updated') <div class="alert">Password updated successfully.</div> @endif
    <form method="POST" action="{{ route('password.update') }}">@csrf @method('PUT')
        <div class="field"><label for="update_password_current_password">Current password</label><input id="update_password_current_password" type="password" name="current_password" autocomplete="current-password">@error('current_password', 'updatePassword') <span class="error">{{ $message }}</span> @enderror</div>
        <div class="field"><label for="update_password_password">New password</label><input id="update_password_password" type="password" name="password" autocomplete="new-password">@error('password', 'updatePassword') <span class="error">{{ $message }}</span> @enderror</div>
        <div class="field"><label for="update_password_password_confirmation">Confirm new password</label><input id="update_password_password_confirmation" type="password" name="password_confirmation" autocomplete="new-password">@error('password_confirmation', 'updatePassword') <span class="error">{{ $message }}</span> @enderror</div>
        <button class="button" type="submit">Update password</button>
    </form>
</section>

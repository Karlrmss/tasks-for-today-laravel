@extends('layouts.app')

@section('title', 'About')

@section('content')
<header class="page-header"><div class="container"><p class="eyebrow">About the project</p><h1>Built for clarity.</h1><p>A practical Laravel application for managing everyday work.</p></div></header>
<section class="section">
    <div class="container prose">
        <h2>Tasks for Today</h2>
        <p>This system was created by Karl Ramos as a full-stack Laravel assessment. It demonstrates complete CRUD workflows, server-side validation, session authentication with Laravel Breeze, and an application email triggered by a meaningful data change.</p>
        <p>Anyone can browse active tasks and the public pages. Creating, editing, archiving, restoring, or managing an account requires authentication. Tasks are archived with an <code>is_archived</code> flag, preserving the record instead of permanently deleting it.</p>
        <h3>Completion notifications</h3>
        <p>When a pending or in-progress task changes to done, Laravel’s Mail facade sends a <code>TaskCompleted</code> mailable to the configured recipient. Saving an already-done task does not send a duplicate email.</p>
        <div class="page-actions"><a class="button" href="{{ route('tasks.index') }}">Explore tasks</a><a class="button secondary" href="{{ route('profile.public') }}">Meet the developer</a></div>
    </div>
</section>
@endsection

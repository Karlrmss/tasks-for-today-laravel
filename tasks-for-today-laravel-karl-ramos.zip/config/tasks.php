<?php

return [
    'completion_recipient' => env('TASK_COMPLETION_RECIPIENT', env('MAIL_FROM_ADDRESS', 'admin@example.com')),
];

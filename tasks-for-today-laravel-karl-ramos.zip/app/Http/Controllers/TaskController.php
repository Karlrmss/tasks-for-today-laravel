<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use App\Mail\TaskCompleted;
use App\Models\Task;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\View\View;

class TaskController extends Controller
{
    public function index(Request $request): View
    {
        $tasks = Task::query()
            ->where('is_archived', false)
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->string('status')))
            ->when($request->filled('search'), function ($query) use ($request) {
                $search = '%'.$request->string('search').'%';
                $query->where(fn ($query) => $query
                    ->where('title', 'like', $search)
                    ->orWhere('description', 'like', $search));
            })
            ->orderByRaw("CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END")
            ->orderBy('due_date')
            ->paginate(9)
            ->withQueryString();

        return view('tasks.index', compact('tasks'));
    }

    public function archived(): View
    {
        $tasks = Task::query()->where('is_archived', true)->latest('updated_at')->paginate(10);

        return view('tasks.archived', compact('tasks'));
    }

    public function create(): View
    {
        return view('tasks.create');
    }

    public function store(StoreTaskRequest $request): RedirectResponse
    {
        Task::create($request->validated());

        return redirect()->route('tasks.index')->with('success', 'Task created successfully.');
    }

    public function show(Task $task): View
    {
        abort_if($task->is_archived && ! auth()->check(), 404);

        return view('tasks.show', compact('task'));
    }

    public function edit(Task $task): View
    {
        abort_if($task->is_archived, 404);

        return view('tasks.edit', compact('task'));
    }

    public function update(UpdateTaskRequest $request, Task $task): RedirectResponse
    {
        abort_if($task->is_archived, 404);

        $validated = $request->validated();
        $becameDone = $task->status !== 'done' && $validated['status'] === 'done';

        $task->update($validated);

        if ($becameDone) {
            Mail::to(config('tasks.completion_recipient'))->send(new TaskCompleted($task));
        }

        return redirect()->route('tasks.show', $task)->with(
            'success',
            $becameDone ? 'Task updated and completion email sent.' : 'Task updated successfully.'
        );
    }

    public function destroy(Task $task): RedirectResponse
    {
        $task->update(['is_archived' => true]);

        return redirect()->route('tasks.index')->with('success', 'Task moved to the archive.');
    }

    public function restore(Task $task): RedirectResponse
    {
        abort_unless($task->is_archived, 404);
        $task->update(['is_archived' => false]);

        return redirect()->route('tasks.archived')->with('success', 'Task restored successfully.');
    }
}

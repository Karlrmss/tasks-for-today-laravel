<?php

namespace App\Http\Requests;

class UpdateTaskRequest extends StoreTaskRequest
{
    // The update form uses the same validated fields as task creation.
}

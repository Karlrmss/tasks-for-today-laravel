# Tasks for Today

A responsive task management system built in Laravel by **Karl Ramos**. The application provides public task browsing, Breeze authentication for management actions, validated CRUD workflows, archive-based deletion, and an automatic email when a task changes to `done`.

## Submission links

- **GitHub repository:** [github.com/Karlrmss/tasks-for-today-laravel](https://github.com/Karlrmss/tasks-for-today-laravel)
- **Hosted application:** Add the production URL after deploying the included Render blueprint.

## Features

- Public Welcome, Task List, Profile, About, and task-detail pages
- Registration, login, password reset, email verification, and account management from Laravel Breeze
- Authenticated task create, edit, update, archive, and restore workflows
- Server-side validation with dedicated Form Request classes
- Search and status filtering, priority sorting, and pagination
- `is_archived` soft deletion that preserves task records
- `TaskCompleted` mailable with a dedicated Blade email template
- Completion email sent only when status transitions from a non-done state to `done`
- Log mail driver by default, safe for local demonstration
- Feature tests for public access, authentication, validation, CRUD, archiving, and email behavior
- Responsive custom interface with no Node.js build step required

## Technology

- PHP 8.3+
- Laravel 13
- Laravel Breeze 2
- SQLite by default (MySQL/PostgreSQL can be configured through Laravel)
- Blade and custom CSS
- PHPUnit 12

## Local setup

### Requirements

- PHP 8.3 or newer with SQLite support
- Composer 2

Clone the repository, enter the project directory, then run:

```bash
composer run setup
php artisan serve
```

Open [http://localhost:8000](http://localhost:8000).

The `setup` script installs PHP packages, creates `.env`, generates an application key, creates the SQLite database, runs all migrations, and seeds demonstration records. The CSS is served directly from `public/css/app.css`, so Node.js is not required.

### Manual setup

```bash
composer install
cp .env.example .env
php artisan key:generate
touch database/database.sqlite
php artisan migrate --seed
php artisan serve
```

### Seeded login

- Email: `karl@example.com`
- Password: `password`

This account is for local assessment only. Change or remove it before using the project in a real environment.

## Mail configuration

The default setup uses Laravel's `log` mailer, so no real message is delivered:

```dotenv
MAIL_MAILER=log
MAIL_FROM_ADDRESS="tasks@example.com"
MAIL_FROM_NAME="${APP_NAME}"
TASK_COMPLETION_RECIPIENT="admin@example.com"
```

To verify the required flow:

1. Log in with the seeded account.
2. Open a pending or in-progress task.
3. Choose **Edit task**, change its status to **Done**, and save.
4. Inspect `storage/logs/laravel.log` for the rendered email.
5. Save the already-done task again and confirm that no second email is logged.

The transition guard lives in `TaskController::update`: it compares the existing status with the validated new status before sending `TaskCompleted` through Laravel's `Mail` facade.

### Optional test SMTP service

For Mailtrap or another safe SMTP inbox, replace the mail values in `.env`:

```dotenv
MAIL_MAILER=smtp
MAIL_HOST=your-sandbox-host
MAIL_PORT=2525
MAIL_USERNAME=your-sandbox-username
MAIL_PASSWORD=your-sandbox-password
MAIL_SCHEME=null
MAIL_FROM_ADDRESS="tasks@example.com"
TASK_COMPLETION_RECIPIENT="recipient@example.com"
```

Never commit `.env` or SMTP credentials.

## Tests and code quality

Run the complete automated suite:

```bash
php artisan test
```

Check Laravel code style:

```bash
./vendor/bin/pint --test
```

The task feature tests explicitly prove that:

- guests can view public pages but cannot mutate task data;
- authenticated users can complete the CRUD and archive/restore flow;
- invalid input is rejected;
- a transition to `done` sends the mailable to the configured recipient; and
- updating a task already marked `done` does not resend the email.

## Project organization

```text
app/
├── Http/Controllers/TaskController.php
├── Http/Requests/{StoreTaskRequest,UpdateTaskRequest}.php
├── Mail/TaskCompleted.php
└── Models/Task.php
database/
├── factories/TaskFactory.php
├── migrations/2026_11_15_000000_create_tasks_table.php
└── seeders/DatabaseSeeder.php
resources/views/
├── emails/tasks/completed.blade.php
├── tasks/
└── auth/ and profile/
tests/Feature/TaskManagementTest.php
```

The migrations and seeder are the reproducible database submission. A binary SQLite database does not need to be committed.

## Authorization rules

| Action | Public | Login required |
| --- | :---: | :---: |
| Welcome, task list, task details, public profile, About | Yes | No |
| Register, login, password recovery | Yes | No |
| Create or edit a task | No | Yes |
| Archive or restore a task | No | Yes |
| Account settings | No | Yes |

All task-management mutation routes are placed inside Laravel's `auth` middleware group. Form Requests also require an authenticated user.

## Deployment

The repository includes a `Dockerfile`, `docker/start.sh`, and `render.yaml` for a Render Blueprint deployment with a persistent SQLite disk.

1. Push the repository to GitHub.
2. In Render, create a new **Blueprint** and select the repository.
3. For `APP_KEY`, paste the result of `php artisan key:generate --show`.
4. Set `APP_URL` to the final Render URL.
5. Set `TASK_COMPLETION_RECIPIENT` to the assessment recipient address.
6. Deploy and run the required completion-email flow.
7. After the first deployment, set `SEED_DATABASE=false` if production should not recreate demo records on future empty databases.

The blueprint uses the log mailer by default. Configure SMTP environment values in Render if an actual sandbox inbox is required. The included persistent disk uses Render's paid Starter plan; another Laravel-capable host may be used without code changes.

## Assessment mapping

- **Functionality:** public pages plus full authenticated CRUD and archive/restore workflows
- **MVC organization:** Eloquent model, resource-style controller, Form Requests, Blade views, mailable, and configuration separated by responsibility
- **Validation and security:** Breeze authentication, CSRF protection, auth middleware, Form Request authorization, and constrained enum values
- **Email:** Mail facade, mailable class, Blade email view, configurable recipient, and transition-only delivery
- **Documentation:** reproducible migration/seeder setup, mail verification steps, automated tests, and deployment assets

## Author

**Karl Ramos**

Built as a Laravel laboratory assessment project.

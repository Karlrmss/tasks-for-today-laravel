<?php

namespace Database\Seeders;

use App\Models\Task;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'karl@example.com'],
            ['name' => 'Karl Ramos', 'password' => 'password']
        );

        Task::firstOrCreate(
            ['title' => 'Finish Laravel assessment'],
            [
                'description' => 'Review the CRUD flow, authentication, and completion email notification.',
                'due_date' => now()->addDays(3),
                'priority' => 'high',
                'status' => 'in_progress',
            ]
        );

        Task::firstOrCreate(
            ['title' => 'Prepare project documentation'],
            [
                'description' => 'Complete the setup, mail configuration, testing, and deployment instructions.',
                'due_date' => now()->addDays(5),
                'priority' => 'medium',
                'status' => 'pending',
            ]
        );

        Task::factory()->count(max(0, 6 - Task::count()))->create();
    }
}

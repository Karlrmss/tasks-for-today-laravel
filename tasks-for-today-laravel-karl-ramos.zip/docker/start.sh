#!/bin/sh
set -eu

database_path="${DB_DATABASE:-/tmp/database.sqlite}"
mkdir -p "$(dirname "$database_path")"
touch "$database_path"

php artisan package:discover --ansi
php artisan migrate --force

if [ "${SEED_DATABASE:-false}" = "true" ]; then
    php artisan db:seed --force
fi

php artisan optimize
exec php artisan serve --host=0.0.0.0 --port="${PORT:-8080}"
